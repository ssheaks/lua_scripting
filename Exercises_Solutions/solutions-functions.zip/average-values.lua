-- Function that receives 5 numbers and returns the average
function average(a, b, c, d, e)
  return (a + b + c + d + e) / 5
end

-- Call the function with some values to test if its correct
print("The average of 3, 4, 3, 6, and 2 is "..average(3, 4, 3, 6, 2))
